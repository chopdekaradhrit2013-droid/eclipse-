const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["_assets/web-BRlLYXIH.js","_assets/index-CrtKQA1D.js"])))=>i.map(i=>d[i]);
import{_ as p}from"./index-Dwq4QkXm.js";import{r as e}from"./index-CrtKQA1D.js";import"./vendor-D5Fgan-x.js";const _=e("App",{web:()=>p(()=>import("./web-BRlLYXIH.js"),__vite__mapDeps([0,1])).then(r=>new r.AppWeb)});export{_ as App};
