const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["_assets/web-BiAJq3BF.js","_assets/index-CrtKQA1D.js"])))=>i.map(i=>d[i]);
import{_ as e}from"./index-Dwq4QkXm.js";import{r as o}from"./index-CrtKQA1D.js";import"./vendor-D5Fgan-x.js";const s=o("Browser",{web:()=>e(()=>import("./web-BiAJq3BF.js"),__vite__mapDeps([0,1])).then(r=>new r.BrowserWeb)});export{s as Browser};
